<?php 
//<!-- always rememeber tawag to ng mga kaalyansa :O para sa taas -->\
include('functions/userfunctions.php'); 
include('includes/header.php'); 
include('includes/slider.php'); 


?>

<div class="py-5">
    <div class= "container">
        <div class = "row">
                    <div class="col-md-12">
                    <h4><strong>Trending Products</strong></h4>
                            <div class="underline mb-2"></div>
                              <div class="owl-carousel">
                                  <?php
                                    $trendingProducts =  getAllTrending();
                                    if(mysqli_num_rows($trendingProducts) > 0)
                                    {
                                          foreach($trendingProducts as $item)
                                          {
                                            ?>
                                              <div class="item">
                                                <a href="product-view.php?product=<?=$item['slug']; ?>">
                                                      <div class="car shadow">
                                                          <div class="card-body">
                                                                  <img src="uploads/<?=$item['image']; ?>" alt="Product Image" class="w-100"> <!-- uploading data from admin category -->
                                                                  <h4 class="text-center"><?=$item['name']; ?></h4> <!-- category name center -->
                                                              </div>
                                                        </div>
                                                  </a>
                                              </div>
                                          <?php
                                          }

                                    }

                                  ?>
                        </div>
                    </div>
             </div>
         </div>
    </div>
</div>
<div class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h4><strong>Products</strong></h4>
                <div class="underline mb-2"></div>
                <div class="row">
                    <?php
                    $allProducts = getAllProducts();
                    if(mysqli_num_rows($allProducts) > 0) {
                        foreach($allProducts as $item) {
                    ?>
                            <div class="col-md-3 mb-4">
                                <a href="product-view.php?product=<?=$item['slug']; ?>">
                                    <div class="card h-100">
                                        <img src="uploads/<?=$item['image']; ?>" alt="Product Image" class="card-img-top">
                                        <div class="card-body">
                                            <h4 class="text-center"><?=$item['name']; ?></h4>
                                        </div>
                                    </div>
                                </a>
                            </div>
                    <?php
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="py-5 bg-f2f2f2">
    <div class= "container">
        <div class = "row">
                    <div class="col-md-12">
                            <h4>About Us</h4>
                                <div class="underline mb-2"></div>
                                <p> 
                                Welcome to Berry Beauty and Cosmetics Emporium, where luscious elegance meets vibrant glamour! Our emporium is more than an online shop; it's a celebration of beauty in all its berry-infused splendor.                               
                               </p>
                                <p> 
                                Founded with a passion for harnessing the exquisite power of berries, our emporium is a tribute to the natural richness that enhances and revitalizes your beauty.                              
                                </p>
                                <p> 
                                Dive into a world of berry-inspired beauty with our curated collections. From sumptuous lip shades to antioxidant-rich skincare, each product is a berry-infused masterpiece crafted to accentuate your natural radiance.                               
                               </p>
                    </div>
             </div>
         </div>
    </div>
</div>

<div class="py-5 bg-dark">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h4 class="text-white">Berry Beauty and Cosmetics</h4>
                <div class="underline mb-2">
                    <a href="index.php" class="text-white"> <i class="fa fa-angle-right"></i> Home</a> <br>
                    <a href="#" class="text-white"> <i class="fa fa-angle-right"></i> About Us</a> <br>
                    <a href="cart.php" class="text-white"> <i class="fa fa-angle-right"></i> My cart</a> <br>
                    <a href="categories.php" class="text-white"> <i class="fa fa-angle-right"></i> Our Collections</a>
                </div>
            </div>
            
            <div class="col-md-6">
                <div class="row">
                    <div class="col-md-6">
                        <h4 class="text-white">Address</h4>
                        <p class="text-white">
                        Jose Catolico Avenue, General Santos City, Philippines
                        </p>
                        <a href="tel:+(083) 552 5782" class="text-white"> <i class="fa fa-phone">(083) 552 5782</i></a>
                    </div>
                    <div class="col-md-6">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1927.0889719639974!2d125.18464226332021!3d6.11535900725306!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x32f79fba75da0f9b%3A0xf77a728ceb9f0ad!2sJose%20Catolico%20Sr.%20Ave.%2C%20General%20Santos%20City%2C%209500%20South%20Cotabato!5e0!3m2!1sen!2sph!4v1701705084622!5m2!1sen!2sph" class="w-100" height="250" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="py-2 bg-danger text-center">
    <p class="mb-0 text-white">All rights reserved. Copyright @ <a href="https://www.facebook.com/p/Berry-Beauty-100063929924459/?paipv=0&eav=AfbeKZ9WtKRH6cRhYDEjOl_dWMBgPVb8Y0-bwC2M8FjE0B-F2HzJeeM-WAJKzdOOZkY&_rdr">Berry Beauty</a>- <?= date('Y') ?></p>
</div>



        <!--eto para sa baba :P  -->
<?php include('includes/footer.php'); ?>

<script>

  $(document).ready(function () 
  {
      $('.owl-carousel').owlCarousel({
          loop:true,
          margin:10,
          nav:true,
          responsive:{
              0:{
                  items:1,
                 
              },
              600:{
                  items:4,
                  
              },
              1000:{
                  items:5,
              }
          }
      })
  });
</script>

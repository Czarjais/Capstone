<?php 
include('functions/userfunctions.php'); 
include('includes/header.php'); 

if(isset($_GET['product'])) {
    $product_slug = $_GET['product'];
    //checking if out product is available on database
    $product_data = getSlugActive("products",$product_slug);
    $product = mysqli_fetch_array($product_data);

    if($product) {
?>
<div class="py-3 bg-primary">
    <div class="container">
        <a class="text-white" href="categories.php">Home</a>
        <a class="text-white" href="categories.php">/ Collections</a>
        <h6 class="text-white"><?= $product['name']; ?></h6>
    </div>
</div>

<div class="bg-light py-4">
    <div class="container product_data mt-3">
        <div class="row">
            <div class="col-md-4">
                <div class="shadow">
                    <img src="uploads/<?=  $product['image']; ?>" alt="Product Image" class="w-100">
                </div>
            </div>
            <div class="col-md-8">
                <h4 class="fw-bold"><?= $product['name']; ?>
                    <span class="float-end text-danger">
                        <?php  if($product['trending']){ echo "Trending"; } ?>
                    </span>
                </h4>
                <hr>
                <p><?= $product['small_description']; ?></p>

                <div class="row">
                    <?php if ($product['selling_price'] != 0 || $product['original_price'] != 0): ?>
                        <div class="col-md-6">
                            <?php if ($product['selling_price'] != 0): ?>
                                <h4>₱ <span class="text-success fw-bold"><?= $product['selling_price']; ?></span></h4>
                            <?php elseif ($product['original_price'] != 0): ?>
                                <h4>₱ <span class="text-success fw-bold"><?= $product['original_price']; ?></span></h4>
                            <?php endif; ?>
                        </div>
                        <?php if ($product['selling_price'] != 0 && $product['original_price'] != 0): ?>
                            <div class="col-md-6">
                                <h4>₱ <s class="text-danger"><?= $product['original_price']; ?></s></h4>
                            </div>
                        <?php endif; ?>
                    <?php else: ?>
                        <div class="col-md-12">
                            <p>This product is not available.</p>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="row">
                    <?php if ($product['selling_price'] == 0 && $product['original_price'] == 0): ?>
                        <div class="col-md-6">
                            <button class="btn btn-danger px-4" disabled>Sorry! The product is not available</button>
                        </div>
                    <?php else: ?>
                        <?php if ($product['qty'] > 0): ?>
                            <div class="col-md-4">
                                <div class="input-group mb-3" style="width:130px">
                                    <button class="input-group-text decrement-btn">-</button>
                                    <input type="text" class="form-control text-center input-qty bg-white" value="1" name="quantity" min="1" max="<?= $product['qty']; ?>">
                                <button class="input-group-text increment-btn">+</button>
                                </div>
                                <p>Total Qty Available: <?= $product['qty']; ?></p> <!-- Display total quantity available -->
                            </div>
                            <div class="col-md-8">
                                <div class="row ">
                                    <div class="col-md-6">
                                        <button class="btn btn-primary px-4 addToCartbtn" value="<?= $product['id']; ?>">
                                            <i class="fa fa-shopping-cart me-2"></i>Add to Cart
                                        </button>
                                    </div>
                                      <div class="col-md-6">
                                        <a href="wishlist.php?id=<?php $userId['p.id'] ?>" class="btn btn-danger px-4">
                                            <i class="fa fa-heart me-2" aria-hidden="true"></i>Add to Wishlist
                                        </a>
                                    </div>

                                </div>
                            </div>
                        <?php else: ?>
                            <div class="col-md-12">
                                <p>This product is out of stock.</p>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>

                <hr>
                <h6>Product Description:</h6>
                <p><?= $product['description']; ?></p>
            </div>
        </div>
    </div>
</div>
<?php
    } else {
        echo "Product is Out of Stock.";
    }
} else {
    echo "Something went wrong";
}

include('includes/footer.php'); 
?>

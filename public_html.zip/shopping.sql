-- Create the 'shopping' database
CREATE DATABASE IF NOT EXISTS shopping;
USE shopping;

-- Create the 'users' table
CREATE TABLE users (
    id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255),
    email VARCHAR(255),
    phone VARCHAR(255),
    password VARCHAR(255),
    role_as TINYINT(4),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP()
);

-- Create the 'orders' table
CREATE TABLE orders (
    id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    tracking_no VARCHAR(191),
    user_id INT(191),
    name VARCHAR(191),
    email VARCHAR(191),
    phone INT(191),
    address MEDIUMTEXT,
    pincode INT(191),
    total_price INT(191),
    payment_mode VARCHAR(191),
    payment_id VARCHAR(191) DEFAULT NULL,
    status TINYINT(4) DEFAULT 0,
    comments VARCHAR(255) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP()
);

-- Create the 'order_items' table
CREATE TABLE order_items (
    id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    order_id INT(191),
    prod_id INT(191),
    qty INT(191),
    price INT(191),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP()
);

-- Create the 'carts' table
CREATE TABLE carts (
    id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    user_id INT(11),
    prod_id INT(11),
    prod_qty INT(11),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP()
);

-- Create the 'adminuser' table
CREATE TABLE adminuser (
    id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255),
    email VARCHAR(255),
    phone INT(11),
    password VARCHAR(255),
    role_as TINYINT(4) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP()
);

-- Create the 'categories' table
CREATE TABLE categories (
    id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255),
    slug VARCHAR(255),
    description VARCHAR(255),
    status INT(4),
    popular INT(4),
    image VARCHAR(191),
    meta_title VARCHAR(191),
    meta_description MEDIUMTEXT,
    meta_keywords MEDIUMTEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP()
);

-- Create the 'products' table
CREATE TABLE products (
    id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    category_id INT(11),
    name VARCHAR(191),
    slug VARCHAR(191),
    small_description MEDIUMTEXT,
    description MEDIUMTEXT,
    original_price INT(11),
    selling_price INT(11),
    image VARCHAR(191),
    qty INT(11),
    status INT(4),
    trending INT(4),
    meta_title VARCHAR(191),
    meta_keywords MEDIUMTEXT,
    meta_description MEDIUMTEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP(),
    FOREIGN KEY (category_id) REFERENCES categories(id)
);

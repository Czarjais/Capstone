<?php 
include('../middleware/adminMiddleware.php');
include('includes/header.php'); 

if(isset($_GET['t'])) {
    $tracking_no = $_GET['t'];
    $orderData = checkTrackingNoValid($tracking_no);
    
    if(mysqli_num_rows($orderData) < 1) {
        echo '<h4>Something went wrong</h4>';
        die();
    }
} else {
    echo '<h4>Invalid request</h4>';
    die();
}

$data = mysqli_fetch_array($orderData);

?>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header bg-primary">
                    <span class="text-white fs-4"> View Order </span>
                    <a href="orders.php" class="btn-warning float-end"> <i class="fa fa-reply"></i> Back</a>
                </div>
               
                        <div class="col-md-6">
                            <h4>Order Details</h4>
                            <hr>

                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Image</th>
                                        <th>Product</th>
                                        <th>Quantity</th>
                                        <th>Price</th>
                                        <th>Subtotal</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $total = 0;
                                    $order_query = "SELECT o.id as oid, o.tracking_no, o.user_id, oi.*, oi.qty as orderqty, p.* FROM orders o, order_items oi, products p WHERE oi.order_id=o.id AND p.id=oi.prod_id AND o.tracking_no='$tracking_no' ";
                                    $order_query_run = mysqli_query($conn, $order_query);

                                    if(mysqli_num_rows($order_query_run) > 0) {
                                        foreach($order_query_run as $item) {
                                            $subtotal = $item['price'] * $item['orderqty'];
                                            $total += $subtotal;
                                    ?>
                                            <tr>
                                            <td class="align-middle">
                                                    <img src="../uploads/<?= $item['image']; ?>" width="50px" height="50px" alt="<?= $item['name']; ?>">
                                                </td>
                                                <td class="align-middle"><?= $item['name']; ?></td>
                                                <td class="align-middle"><?= $item['orderqty']; ?></td>
                                                <td class="align-middle">&#36; <?= number_format($item['price'], 2); ?></td>
                                                <td class="align-middle">&#36; <?= number_format($subtotal, 2); ?></td>
                                            </tr>
                                    <?php
                                        }
                                    }
                                    ?>
                                </tbody>
                            </table>

                            <hr>
                            <h5>Total Price: <span class="float-end fw-bold">&#36; <?= number_format($total, 2); ?> </span> </h5>
                            <hr>
                            <label class="fw-bold">Payment Mode</label>
                            <div class="border p-1 mb-3">
                                <?= $data['payment_mode'] ?>
                            </div>
                            <label class="fw-bold">Status</label>
                            <div class="mb-3">
                                    <label class="fw-bold">Status</label>
                                    <div class="border p-1">
                                        <?php
                                        $statusText = '';
                                        switch ($data['status']) {
                                            case 0:
                                                $statusText = 'Order Placed';
                                                break;
                                            case 1:
                                                $statusText = 'Preparing to ship';
                                                break;
                                            case 2:
                                                $statusText = 'Parcel is out for Delivery';
                                                break;
                                            case 3:
                                                $statusText = 'Order Delivered';
                                                break;
                                            case 4:
                                                $statusText = 'Order Cancelled';
                                                break;
                                            default:
                                                $statusText = 'Unknown Status';
                                        }
                                        echo $statusText;
                                        ?>
                                    </div>
                                </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include('includes/footer.php'); ?>

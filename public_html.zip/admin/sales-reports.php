<?php
include('../middleware/adminMiddleware.php');
include('includes/header.php');
// Fetch all orders
$orders = getAllOrders();

// Fetch orders history
$ordersHistory = getOrdersHistory();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sales Reports</title>
    <!-- Include your CSS and other dependencies here -->
</head>
<body>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header bg-primary">
                    <h4 class="text-white">
                        Sales Reports
                    </h4>
                </div>
                <ol class="breadcrumb">
                    <li><a href="index.php"><i class="fa fa-dashboard"></i> Home</a></li>
                    <li class="active">Sales</li>
                </ol>
            </div>

            <!-- Main content -->
            <section class="content">
                <div class="row">
                    <div class="col-xs-12">
                        <div class="box">
                            <div class="box-header with-border">
                                <div class="pull-right">
                                    <form method="POST" class="form-inline" action="print.php">
                                        <div class="input-group">
                                            <div class="input-group-addon">
                                                <i class="fa fa-calendar"></i>
                                            </div>
                                            <input type="text" class="form-control pull-right col-sm-8" id="reservation" name="date_range">
                                        </div>
                                        <button type="submit" class="btn btn-success btn-sm btn-flat" name="print">
                                            <span class="glyphicon glyphicon-print"></span> Print
                                        </button>
                                    </form>
                                </div>
                            </div>

                            <div class="box-body">
                                <table id="example1" class="table table-bordered">
                                    <thead>
                                        <th class="hidden"></th>
                                        <th>Date</th>
                                        <th>Buyer Name</th>
                                        <th>Transaction#</th>
                                        <th>Amount</th>
                                        <th>Full Details</th>
                                        
                                    </thead>
                                    <tbody>
                                        <?php
                                        if ($orders) {
                                            foreach ($orders as $order) {
                                                // Assuming displayOrderRow is a function that displays order details
                                                displayOrderRow($order);
                                            }
                                        } else {
                                            echo '<tr><td colspan="5">No Orders yet</td></tr>';
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
<?php include 'includes/scripts.php'; ?>

</body>
</html>

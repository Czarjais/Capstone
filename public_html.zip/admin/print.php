<?php
include('../middleware/adminMiddleware.php');
include('includes/header.php');

?>

<!DOCTYPE html>
<html>
<head>
    <title>Sales Report</title>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"/>
</head>

<body>
    <div class="container">
        <div class="row">
            <div class="col-xl-12">
                <h1>Sales Report</h1>
                <table class="table">
                    <thead>
                        <th>Date</th>
                        <th>Buyer Name</th>
                        <th>Transaction#</th>
                        <th>Amount</th>
                    </thead>
                    <tbody>
                        <?php
                        $sql = "SELECT * FROM orders";
                        $result = mysqli_query($conn, $sql);

                        while ($row = mysqli_fetch_assoc($result)) {
                            echo "<tr>";
                            echo "<td>{$row['created_at']}</td>";
                            echo "<td>{$row['name']}</td>";
                            echo "<td>{$row['tracking_no']}</td>";
                            echo "<td>₱ {$row['total_price']}</td>";
                            echo "</tr>";
                        }
                        ?>
                    </tbody>
                </table>
                <div class="text-center">
                    <button onclick="window.print()" class="btn btn-primary">Print</button>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

<?php
// Close the database connection
mysqli_close($conn);
?>

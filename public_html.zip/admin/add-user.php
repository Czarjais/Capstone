<?php

include('../middleware/adminMiddleware.php');
include('includes/header.php');

?>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4>Add Admin User</h4>
                </div>
                <div class="card-body">
                    <form action="code.php" method="POST"><!-- POST METHOD SUBMITTING DATA -->
                        <div class="row">
                            <div class="col-md-6">
                                <label class="mb-0">Name</label>
                                <input type="text" required name="name" placeholder="Enter Name" class="form-control mb-2">
                            </div>

                            <div class="col-md-6">
                                <label class="mb-0">Email</label>
                                <input type="email" required name="email" placeholder="Enter Email" class="form-control mb-2">
                            </div>

                            <div class="col-md-6">
                                <label class="mb-0">Phone</label>
                                <input type="text" required name="phone" placeholder="Enter Phone" class="form-control mb-2">
                            </div>

                            <div class="col-md-6">
                                <label class="mb-0">Password</label>
                                <input type="password" required name="password" placeholder="Enter Password" class="form-control mb-2">
                            </div>

                            <div class="col-md-6">
                                <label class="mb-0">Role</label>
                                <select name="role_as" class="form-select mb-2">
                                    <option value="0">User</option>
                                    <option value="1">Admin</option>
                                </select>
                            </div>

                            <div class="col-md-12">
                                <button type="submit" class="btn btn-primary add_adminuser_btn" name="add_adminuser_btn">Submit</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    // JavaScript to handle form submission and page reload
    $(document).ready(function () {
        $('#addUserForm').submit(function (e) {
            e.preventDefault();

            // Perform AJAX request to handle form submission
            $.ajax({
                method: "POST",
                url: "code.php",
                data: $('#addUserForm').serialize(),
                success: function (response) {
                    console.log(response);
                    // Handle success or error messages as needed

                    // Reload the page after form submission
                    location.reload();
                }
            });
        });
    });
</script>

<?php include('includes/footer.php'); ?>

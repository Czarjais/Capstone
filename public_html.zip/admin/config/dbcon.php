<?php
        $host = "localhost";
        $username = "root";
        $password = "";
        $database ="shopping";
        //Databse connection<<<<
        $conn = mysqli_connect($host, $username, $password, $database);
        //if there's no connection this code whill functions
        if (!$conn) {
            die("Connection failed: ". mysqli_connect_error());
        }
?>
<?php

include('../middleware/adminMiddleware.php');
include('includes/header.php');

if (isset($_GET['id'])) {
    $user_id = mysqli_real_escape_string($conn, $_GET['id']);

    $select_query = "SELECT * FROM adminuser WHERE id = '$user_id'";
    $select_query_run = mysqli_query($conn, $select_query);

    if (mysqli_num_rows($select_query_run) > 0) {
        $user_data = mysqli_fetch_assoc($select_query_run);
        $name = $user_data['name'];
        $email = $user_data['email'];
        $phone = $user_data['phone'];
        $password = $user_data['password'];
        $role_as = $user_data['role_as'];
    } else {
        // User not found, handle accordingly (redirect or show an error message)
        echo "User not found.";
    }
} else {
    // ID not provided in the URL, handle accordingly (redirect or show an error message)
    echo "User ID not provided.";
}
?>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4>Edit Admin User</h4>
                </div>
                <div class="card-body">
                    <form action="code.php" method="POST"><!-- POST METHOD SUBMITTING DATA -->
                        <div class="row">
                            <div class="col-md-6">
                                <label class="mb-0">Name</label>
                                <input type="text" required name="name" value="<?php echo $name; ?>" class="form-control mb-2">
                            </div>

                            <div class="col-md-6">
                                <label class="mb-0">Email</label>
                                <input type="text" required name="email" value="<?php echo $email; ?>" class="form-control mb-2">
                            </div>

                            <div class="col-md-6">
                                <label class="mb-0">Phone</label>
                                <input type="text" required name="phone" value="<?php echo $phone; ?>" class="form-control mb-2">
                            </div>

                            <div class="col-md-6">
                                <label class="mb-0">Password</label>
                                <input type="text" required name="password" value="<?php echo $password; ?>" class="form-control mb-2">
                            </div>

                            <div class="col-md-6">
                                <label class="mb-0">Role</label>
                                <select name="role_as" class="form-select mb-2">
                                    <option value="0" <?php echo ($role_as == 0) ? 'selected' : ''; ?>>User</option>
                                    <option value="1" <?php echo ($role_as == 1) ? 'selected' : ''; ?>>Admin</option>
                                </select>
                            </div>

                            <input type="hidden" name="user_id" value="<?php echo $user_id; ?>">

                            <div class="col-md-12">
                                <button type="submit" class="btn btn-primary edit_user_btn" name="edit_user_btn">Submit</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include('includes/footer.php'); ?>

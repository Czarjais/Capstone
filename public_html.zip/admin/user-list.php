<?php

include('../middleware/adminMiddleware.php');
include('includes/header.php');

?>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4>User</h4>
                    <div class="card-body">
                        <div class="mb-3">
                            <a href="add-user.php" class="btn btn-primary">Add User</a>
                        </div>
                    </div>
                    <div class="card-body" id="products_table">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Password</th>
                                    <th>Role</th>
                                    <th>Create Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                //getalll function on code.php
                                $adminuser = getAll("adminuser");
                                if (mysqli_num_rows($adminuser) > 0) {
                                    foreach ($adminuser as $item) {
                                        //imprint database = is echo
                                ?>
                                        <tr>
                                            <td><?= $item['id']; ?></td>
                                            <td><?= $item['name']; ?></td>
                                            <td><?= $item['email']; ?></td>
                                            <td><?= $item['password']; ?></td>
                                            <td><?= $item['role_as']; ?></td>
                                            <td><?= $item['created_at']; ?></td>
                                            <td>
                                                <button type="button" class="btn btn-sm btn-danger delete_adminuser_btn" value="<?= $item['id']; ?>">Delete</button>
                                                <a href="edit-user.php?id=<?= $item['id']; ?>" class="btn btn-primary">Edit</a>
                                                <button type="button" class="btn btn-danger archive_adminuser_btn" onclick="archiveUser(<?= $item['id']; ?>)">Archive</button>

                                            <script>
                                                function archiveUser(userId) {
                                                    var confirmArchive = confirm("Are you sure you want to archive this user?");
    
                                                    if (confirmArchive) {
                                                    // User confirmed, proceed with archiving
                                                    var form = document.createElement("form");
                                                    form.method = "POST";
                                                    form.action = "code.php"; // Replace with your backend script

                                                    var input = document.createElement("input");
                                                    input.type = "hidden";
                                                    input.name = "user_id";
                                                    input.value = userId;

                                                    form.appendChild(input);
                                                    document.body.appendChild(form);

                                                    form.submit();
                                                    }
                                                }
                                            </script>

                                            </td>
                                        </tr>
                                <?php
                                    }
                                } else {
                                    echo "No Record Found";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include('includes/footer.php'); ?>

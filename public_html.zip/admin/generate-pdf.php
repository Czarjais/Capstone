<?php
// generate-pdf.php

// Include TCPDF library
require('tcpdf/tcpdf.php');

// Create PDF object
$pdf = new TCPDF();

// Remove any previous output
ob_clean();

// Add content to PDF (no output or HTML content before this)
$pdf->AddPage();
$pdf->SetFont('times', 'B', 16);
$pdf->Cell(40, 10, 'Hello, World!');

// Output PDF to the browser
$pdf->Output();

<?php
        $host = "localhost";
        $username = "u819905533_berrybeautyDB";
        $password = "!Berrryadmin123";
        $database ="u819905533_shopping";
        //Databse connection<<<<
        $conn = mysqli_connect($host, $username, $password, $database);
        //if there's no connection this code whill functions
        if (!$conn) { //this little conn is variable for database i getting error beacuase of this be careful
            die("Connection failed: ". mysqli_connect_error());
        }
        try {
            $pdo = new PDO("mysql:host=$host;dbname=$database", $username, $password);
            // Set PDO attributes if needed
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            die("Connection failed: " . $e->getMessage());
        }
?>
$(document).ready(function () {

    $('.increment-btn').click(function (e) { 
        e.preventDefault();

        var qtyInput = $(this).closest('.product_data').find('.input-qty');
        var qty = parseInt(qtyInput.val(), 10);
        qty = isNaN(qty) ? 0 : qty;

        if (qty < 100) {
            qty++;
            qtyInput.val(qty);
            updateTotalPrice(qty);
        }
    });

    $('.decrement-btn').click(function (e) { 
        e.preventDefault();

        var qtyInput = $(this).closest('.product_data').find('.input-qty');
        var qty = parseInt(qtyInput.val(), 10);
        qty = isNaN(qty) ? 0 : qty;

        if (qty > 1) {
            qty--;
            qtyInput.val(qty);
            updateTotalPrice(qty);
        }
    });

   

    // Rest of your existing code...


    

    $('.addToCartbtn').click(function (e) {
        e.preventDefault();

        var qtyInput = $(this).closest('.product_data').find('.input-qty');
        var qty = parseInt(qtyInput.val(), 100);
        var prod_id = $(this).val();

        $.ajax({
            method: "POST",
            url: "functions/handlecart.php",
            data: {
                "prod_id": prod_id,
                "prod_qty": qty,
                "scope": 'add'
            },
            success: function (response) {
                switch (response) {
                    case '201':
                        alertify.success("Product added to cart");
                        break;
                    case 'existing':
                        alertify.success("Product already in cart");
                        break;
                    case '401':
                        alertify.success("Login to continue");
                        break;
                    case '500':
                        alertify.success("Something went wrong");
                        break;
                    default:
                        // Handle unexpected response
                        console.log("Unexpected response:", response);
                }
            }
        });
    });

    

    $(document).on('click','.updateQty', function () {
        var qtyInput = $(this).closest('.product_data').find('.input-qty');
        var qty = qtyInput.val();
        var prod_id = $(this).closest('.product_data').find('.prodId').val();

        $.ajax({
            method: "POST",
            url: "functions/handlecart.php",
            data: {
                "prod_id": prod_id,
                "prod_qty" : qty,
                "scope" : 'update'
            },
            success: function (response) {
                // Assuming 'response' is the new total price after the update
                var newTotalPrice = parseFloat(response).toFixed(2);
                
                // Update the displayed total price
                qtyInput.closest('.row').find('.total-price').html('Total Price: ₱' + newTotalPrice);
            }
        });
    });
    $(document).on('click','.deleteItem', function () {
        var cart_id = $(this).val();
       // alert(cart_id);

       $.ajax({
        method: "POST",
        url: "functions/handlecart.php",
        data: {
            "cart_id": cart_id,
            "scope" : 'delete'
        },
        success: function (response) 
        {
            if(response == 200)
            {
            alertify.success("Item remove successfuly");
            $('#mycart').load(location.href + " #mycart");
            }
            else
            {
                alertify.success(response);

            }
        }
    });

        
    });


});



<?php

include('../functions/myfunction.php');

// anti autopath security for admin
// to prevent direct access to admin pages via URL

if (isset($_SESSION['auth'])) {
    // Comment out the redirection part to check if it resolves the issue
    
    if ($_SESSION['role_as'] != 1) {
        redirect("../index.php", "You don't have access to this page");
    }
    
} else {
    redirect("../login.php", "Login to continue");
}
?>
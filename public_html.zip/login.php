<!-- always rememeber tawag to ng mga kaalyansa :O para sa taas --> 
<?php 
    session_start();
//this code is for anti URL path like you want to access the register but you already log in
//it will give you message that you are already log in if you want to access the url register
    if(isset($_SESSION['auth']))
    {
        $_SESSION['message'] = "You are already logged In";
        header('Location: index.php');
        exit();
    }
    include('includes/header.php'); 
?>
<!--Bootstrap form Begin yung log in na bootstrap simula dito :D -->
<div class="py-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <?php 
                             if(isset($_SESSION['message'])) 
                 { 
                             ?>
                            <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                <strong>Warning!</strong> <?= $_SESSION['message']; ?>.
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                            <?php 
                            unset($_SESSION['message']); 
                 }
                            ?>


                <div class="card">
                    <div class="card-header">
                        <h4>Login <Form:post></Form:post></h4>
                    </div>
                    <div class="card-body">
                        <form action="functions/authcode.php" method="POST">
                            <div class="mb-3">
                                <label for="exampleInputEmail1" class="form-label">Email address</label>
                                <input type="email" name="email" class="form-control" placeholder="Email address" id="exampleInputEmail1">
                            </div>
                            <div class="mb-3">
                                <label for="exampleInputPassword1" class="form-label">Password</label>
                                <input type="password" name="password" class="form-control" placeholder="Password" id="exampleInputPassword1">
                            </div>
                            <button type="submit" name="login_btn" class="btn btn-primary">Login</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
            <!--dito nag tatapos ang bootstrap form :D -->
<?php include('includes/footer.php'); ?>
             <!--eto para sa baba :P  -->


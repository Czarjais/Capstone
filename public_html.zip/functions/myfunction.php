<?php
session_start();
include('../config/dbcon.php');

function getAll($table)
{
    global $conn;
    $query = "SELECT * FROM $table";
    return $query_run  = mysqli_query($conn, $query);
}

function getByID($table, $id)
{
    global $conn;
    $query = "SELECT * FROM $table WHERE id='$id' ";
    return $query_run  = mysqli_query($conn, $query);
}



function redirect($url, $message)
{
    $_SESSION['message'] = $message;
    header('Location:'.$url);
    exit();
}

function getAllOrders()
{
    global $conn;
    $query = "SELECT * FROM orders WHERE status='0'";
    return $query_run  = mysqli_query($conn, $query);
}

function getOrdersHistory()
{
    global $conn;
    $query = "SELECT * FROM orders WHERE status !='0'";
    return $query_run  = mysqli_query($conn, $query);
}

function checkTrackingNoValid($trackingNo)
{
    global $conn;
    $query = "SELECT * FROM orders WHERE tracking_no='$trackingNo' ";
    return mysqli_query($conn, $query);
}


function getOrderDetails($orderId)
{
    global $conn;
    // Add error handling
    try {
        $stmt = $conn->prepare("SELECT * FROM order_items WHERE order_id = :id");
        $stmt->execute(['id' => $orderId]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        echo $e->getMessage();
    }
}

function calculateTotal($orderDetails)
{
    $total = 0;
    foreach ($orderDetails as $details) {
        $subtotal = $details['price'] * $details['quantity'];
        $total += $subtotal;
    }
    return $total;
}
function displayOrderRow($order)
{
    echo "
        <tr>
            <td class='hidden'></td>
            <td>" . date('M d, Y', strtotime($order['created_at'])) . "</td>
            <td>{$order['name']}</td>
            <td>{$order['tracking_no']}</td>
            <td>&#36; " . number_format($order['total_price'], 2) . "</td>
            <td><a href='sales-view-order.php?t={$order['tracking_no']}' class='btn btn-primary'>View Details</a></td>
        </tr>
    ";
}



?>
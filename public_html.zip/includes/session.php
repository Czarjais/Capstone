<?php
	include 'includes/conn.php';
	include('../middleware/adminMiddleware.php');
    include('includes/header.php');
	include('config/dbcon.php');
	session_start();

	if(isset($_SESSION['admin'])){
		header('location: admin/home.php');
	}

	if(isset($_SESSION['adminuser'])){
		$conn = $pdo->open();

		try{
			$stmt = $conn->prepare("SELECT * FROM adminuser WHERE id=:id");
			$stmt->execute(['id'=>$_SESSION['adminuser']]);
			$user = $stmt->fetch();
		}
		catch(PDOException $e){
			echo "There is some problem in connection: " . $e->getMessage();
		}

		$pdo->close();
	}
?>